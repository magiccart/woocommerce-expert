<?php
/**
 * Magiccart 
 * @category    Magiccart 
 * @copyright   Copyright (c) 2014 Magiccart (http://www.magiccart.net/) 
 * @license     http://www.magiccart.net/license-agreement.html
 * @Author: DOng NGuyen<nguyen@dvn.com>
 * @@Create Date: 2018-05-17 10:22:36
 * @@Modify Date: 2018-06-21 17:51:09
 * @@Function:
 */

namespace Alothemes\Element\Block;

class Wishlist extends Template{

}

