<?php
/**
 * Magiccart 
 * @category    Magiccart 
 * @copyright   Copyright (c) 2014 Magiccart (http://www.magiccart.net/) 
 * @license     http://www.magiccart.net/license-agreement.html
 * @Author: DOng NGuyen<nguyen@dvn.com>
 * @@Create Date: 2018-05-17 12:11:00
 * @@Modify Date: 2018-05-17 14:42:25
 * @@Function:
 */
 
namespace Alothemes\Core\Block;

use Alothemes\Core\Block\Template\AbstractTemplate;

class Template extends AbstractTemplate{


}
