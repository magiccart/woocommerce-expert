(function ( $ ) {
    var how_to_link = $( '#yith-how-to-premium' ).parent();
    if ( typeof how_to_link != 'undefined' ) {
        how_to_link.prop( 'target', '_blank' );
    }
})( jQuery );
