<?php
namespace Magiccart\Megamenu\Model\Menu;

class Collection{
    public function __construct(){
        
    }
}