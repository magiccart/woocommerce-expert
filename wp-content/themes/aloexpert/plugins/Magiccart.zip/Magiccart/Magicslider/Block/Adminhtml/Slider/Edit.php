<?php
/**
 * Magiccart 
 * @category 	Magiccart 
 * @copyright 	Copyright (c) 2014 Magiccart (http://www.magiccart.net/) 
 * @license 	http://www.magiccart.net/license-agreement.html
 * @Author: DOng NGuyen<nguyen@dvn.com>
 * @@Create Date: 2017-08-23 20:55:31
 * @@Modify Date: 2017-08-23 20:56:03
 * @@Function:
 */
 
namespace Magiccart\Magicslider\Block\Adminhtml\Slider;

use Magiccart\Core\Block\Adminhtml\Template;

class Edit extends Template{

}
