<?php
/**
 * Magiccart 
 * @category 	Magiccart 
 * @copyright 	Copyright (c) 2014 Magiccart (http://www.magiccart.net/) 
 * @license 	http://www.magiccart.net/license-agreement.html
 * @Author: DOng NGuyen<nguyen@dvn.com>
 * @@Create Date: 2017-12-08 14:18:58
 * @@Modify Date: 2017-12-26 14:32:34
 * @@Function:
 */

namespace Magiccart\Import\Block\Adminhtml;

use Magiccart\Core\Block\Adminhtml\Template;

class Import extends Template{

}
