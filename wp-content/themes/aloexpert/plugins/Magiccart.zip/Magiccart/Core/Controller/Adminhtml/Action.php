<?php
/**
 * Magiccart 
 * @category 	Magiccart 
 * @copyright 	Copyright (c) 2014 Magiccart (http://www.magiccart.net/) 
 * @license 	http://www.magiccart.net/license-agreement.html
 * @Author: DOng NGuyen<nguyen@dvn.com>
 * @@Create Date: 2017-08-23 22:23:31
 * @@Modify Date: 2017-09-13 23:24:50
 * @@Function:
 */
 
namespace Magiccart\Core\Controller\Adminhtml;

use Magiccart\Core\Controller\AbstractAction;

class Action extends AbstractAction { 

}
