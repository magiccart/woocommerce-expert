<?php
/**
 * Magiccart 
 * @category 	Magiccart 
 * @copyright 	Copyright (c) 2014 Magiccart (http://www.magiccart.net/) 
 * @license 	http://www.magiccart.net/license-agreement.html
 * @Author: DOng NGuyen<nguyen@dvn.com>
 * @@Create Date: 2017-08-24 10:26:08
 * @@Modify Date: 2017-08-24 10:26:31
 * @@Function:
 */

namespace Magiccart\Core\Block\Adminhtml;

use Magiccart\Core\Block\Template\AbstractTemplate;

class Template extends AbstractTemplate{
   
}
