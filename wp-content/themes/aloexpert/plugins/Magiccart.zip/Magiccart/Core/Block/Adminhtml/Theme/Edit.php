<?php
namespace Magiccart\Core\Block\Adminhtml\Theme;

use Magiccart\Core\Block\Adminhtml\Template;

class Edit extends Template{
   public $_template= 'theme/edit.phtml'; 
}
