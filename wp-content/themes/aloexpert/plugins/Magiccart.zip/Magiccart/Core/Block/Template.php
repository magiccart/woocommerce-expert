<?php
/**
 * Magiccart 
 * @category    Magiccart 
 * @copyright   Copyright (c) 2014 Magiccart (http://www.magiccart.net/) 
 * @license     http://www.magiccart.net/license-agreement.html
 * @Author: DOng NGuyen<nguyen@dvn.com>
 * @@Create Date: 2017-07-24 12:11:00
 * @@Modify Date: 2017-08-24 10:27:14
 * @@Function:
 */
 
namespace Magiccart\Core\Block;

use Magiccart\Core\Block\Template\AbstractTemplate;

class Template extends AbstractTemplate{


}
