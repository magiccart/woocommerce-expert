<?php
/**
 * Magiccart 
 * @category 	Magiccart 
 * @copyright 	Copyright (c) 2014 Magiccart (http://www.magiccart.net/) 
 * @license 	http://www.magiccart.net/license-agreement.html
 * @Author: DOng NGuyen<nguyen@dvn.com>
 * @@Create Date: 2017-08-24 11:16:58
 * @@Modify Date: 2017-08-24 11:17:51
 * @@Function:
 */

namespace Magiccart\Shopbrand\Block\Adminhtml\Brand;

use Magiccart\Core\Block\Adminhtml\Template;

class Edit extends Template
{

}
