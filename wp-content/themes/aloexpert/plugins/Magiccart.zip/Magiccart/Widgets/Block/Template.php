<?php
/**
 * Magiccart 
 * @category 	Magiccart 
 * @copyright 	Copyright (c) 2014 Magiccart (http://www.magiccart.net/) 
 * @license 	http://www.magiccart.net/license-agreement.html
 * @Author: DOng NGuyen<nguyen@dvn.com>
 * @@Create Date: 2018-06-03 19:22:49
 * @@Modify Date: 2018-06-04 11:19:10
 * @@Function:
 */

namespace Magiccart\Widgets\Block;

class Template extends \Magiccart\Core\Block\Template 
{

}
