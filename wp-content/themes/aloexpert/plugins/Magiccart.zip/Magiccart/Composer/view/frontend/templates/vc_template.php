<?php 
/**
 * Magiccart 
 * @category    Magiccart 
 * @copyright   Copyright (c) 2014 Magiccart (http://www.magiccart.net/) 
 * @license     http://www.magiccart.net/license-agreement.html
 * @Author: DOng NGuyen<nguyen@dvn.com>
 * @@Create Date: 2017-08-13 18:45:34
 * @@Modify Date: 2017-08-13 21:59:01
 * @@Function:
 */

echo __('This is vc_template', 'alothemes');